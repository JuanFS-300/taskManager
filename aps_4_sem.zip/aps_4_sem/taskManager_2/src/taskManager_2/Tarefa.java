package taskManager_2;

public class Tarefa {
    private String nome;
    private String descricao;
    private String categoria;
    private String data;
    private int id;

    public Tarefa(String categoria, String nome, String descricao, String data, int id) {
        this.categoria = categoria;
        this.nome = nome;
        this.descricao = descricao;
        this.data = data;
        this.id = id;
    }

    // Getters e setters
    public String getNome() { return nome; }
    public String getDescricao() { return descricao; }
    public String getCategoria() { return categoria; }
    public String getData() { return data; }
    public int getId() { return id; }
}
