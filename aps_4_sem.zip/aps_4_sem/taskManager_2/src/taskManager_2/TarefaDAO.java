package taskManager_2;

import java.util.List;

public interface TarefaDAO {
    void adicionarTarefa(Tarefa tarefa);
    List<Tarefa> listarTarefas();
    List<Tarefa> listarTarefasOrdenadas(String criterio);
    List<Tarefa> buscarTarefasPorCategoria(String categoria);
}
