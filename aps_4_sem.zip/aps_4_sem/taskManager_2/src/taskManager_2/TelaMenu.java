package taskManager_2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;

public class TelaMenu extends JFrame {
    private static final long serialVersionUID = 1L;
    private CardLayout cardLayout;
    private JPanel painelPrincipal;
    private TarefaController tarefaController;

    public TelaMenu() {
        tarefaController = new TarefaController();
        setTitle("Task Manager");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Menu");
        JMenuItem adicionarTarefaItem = new JMenuItem("Adicionar Tarefa");
        JMenuItem listarTarefasItem = new JMenuItem("Listar Tarefas");
        JMenuItem filtrarTarefasItem = new JMenuItem("Filtrar Tarefas");
        JMenuItem voltar = new JMenuItem("Voltar � tela inicial");

        menu.add(adicionarTarefaItem);
        menu.add(listarTarefasItem);
        menu.add(filtrarTarefasItem);
        menu.add(voltar);
        menuBar.add(menu);
        setJMenuBar(menuBar);

        cardLayout = new CardLayout();
        painelPrincipal = new JPanel(cardLayout);

        painelPrincipal.add(criarTelaBoasVindas(), "Tela Boas Vindas");
        painelPrincipal.add(criarTelaAdicionarTarefa(), "Tela Adicionar Tarefa");
        painelPrincipal.add(criarTelaListarTarefas(), "Tela Listar Tarefas");
        painelPrincipal.add(criarTelaFiltrarTarefas(), "Tela Filtrar Tarefas");

        add(painelPrincipal, BorderLayout.CENTER);

        adicionarTarefaItem.addActionListener(e -> cardLayout.show(painelPrincipal, "Tela Adicionar Tarefa"));
        listarTarefasItem.addActionListener(e -> cardLayout.show(painelPrincipal, "Tela Listar Tarefas"));
        filtrarTarefasItem.addActionListener(e -> cardLayout.show(painelPrincipal, "Tela Filtrar Tarefas"));
        voltar.addActionListener(e -> cardLayout.show(painelPrincipal, "Tela Boas Vindas"));
    }

    private JPanel criarTelaBoasVindas() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        panel.setBackground(new Color(240, 248, 255));
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel mensagemBoasVindas = new JLabel("Bem-vindo ao Task Manager!", JLabel.CENTER);
        mensagemBoasVindas.setFont(new Font("Arial", Font.BOLD, 16));
        mensagemBoasVindas.setForeground(new Color(60, 63, 65));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(mensagemBoasVindas, gbc);

        JPanel botoesPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        botoesPanel.setBackground(new Color(240, 248, 255));
        JButton btnAdicionarTarefa = new JButton("Adicionar Tarefa");
        JButton btnListarTarefas = new JButton("Listar Tarefas");
        JButton btnFiltrarTarefas = new JButton("Filtrar Tarefas");

        estilizarBotao(btnAdicionarTarefa);
        estilizarBotao(btnListarTarefas);
        estilizarBotao(btnFiltrarTarefas);

        botoesPanel.add(btnAdicionarTarefa);
        botoesPanel.add(btnListarTarefas);
        botoesPanel.add(btnFiltrarTarefas);

        gbc.gridy = 1;
        panel.add(botoesPanel, gbc);

        btnAdicionarTarefa.addActionListener(e -> cardLayout.show(painelPrincipal, "Tela Adicionar Tarefa"));
        btnListarTarefas.addActionListener(e -> cardLayout.show(painelPrincipal, "Tela Listar Tarefas"));
        btnFiltrarTarefas.addActionListener(e -> cardLayout.show(painelPrincipal, "Tela Filtrar Tarefas"));

        return panel;
    }

    private JPanel criarTelaAdicionarTarefa() {
        JPanel panel = new JPanel(new BorderLayout());
        JPanel formPanel = new JPanel(new GridLayout(7, 1));

        JTextField nomeField = new JTextField();
        JTextField descricaoField = new JTextField();
        JTextField dataFieldDia = new JTextField(2);
        JTextField dataFieldMes = new JTextField(2);
        JTextField dataFieldAno = new JTextField(4);

        // Adicionando KeyListeners para permitir apenas n�meros e notificar o usu�rio
        KeyListener numericKeyListener = new KeyAdapter() {
            @Override
            public void keyTyped(KeyEvent e) {
                char c = e.getKeyChar();
                JTextField source = (JTextField) e.getSource();
                if (!Character.isDigit(c)) {
                    e.consume(); // Ignora o caractere se n�o for um d�gito
                    JOptionPane.showMessageDialog(panel, "Somente n�meros s�o permitidos!", "Entrada inv�lida", JOptionPane.WARNING_MESSAGE);
                    source.setText(""); // Limpa o campo
                }
            }
        };
        dataFieldDia.addKeyListener(numericKeyListener);
        dataFieldMes.addKeyListener(numericKeyListener);
        dataFieldAno.addKeyListener(numericKeyListener);

        JPanel dataPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        dataPanel.add(new JLabel("Dia:"));
        dataPanel.add(dataFieldDia);
        dataPanel.add(new JLabel("M�s:"));
        dataPanel.add(dataFieldMes);
        dataPanel.add(new JLabel("Ano:"));
        dataPanel.add(dataFieldAno);

        formPanel.setBackground(new Color(240, 248, 255));
        panel.setBackground(new Color(240, 248, 255));
        dataPanel.setBackground(new Color(240, 248, 255));
        
        JButton adicionarButton = new JButton("Adicionar");
        estilizarBotao(adicionarButton);

        String[] categorias = {"Estudos", "Dom�stico", "Trabalho", "Variados"};
        JComboBox<String> categoriaComboBox = new JComboBox<>(categorias);

        formPanel.add(new JLabel("Nome da Tarefa:"));
        formPanel.add(nomeField);
        formPanel.add(new JLabel("Descri��o:"));
        formPanel.add(descricaoField);
        formPanel.add(dataPanel);
        formPanel.add(new JLabel("Categoria:"));
        formPanel.add(categoriaComboBox);

        panel.add(formPanel, BorderLayout.CENTER);
        panel.add(adicionarButton, BorderLayout.SOUTH);

        adicionarButton.addActionListener(e -> {
            String nome = nomeField.getText().trim();
            String descricao = descricaoField.getText().trim();
            String dataDia = dataFieldDia.getText().trim();
            String dataMes = dataFieldMes.getText().trim();
            String dataAno = dataFieldAno.getText().trim();
            String categoria = (String) categoriaComboBox.getSelectedItem();

            // Verifica se algum campo est� vazio
            if (nome.isEmpty() || descricao.isEmpty() || dataDia.isEmpty() || dataMes.isEmpty() || dataAno.isEmpty()) {
                JOptionPane.showMessageDialog(panel, "Por favor, preencha todos os campos antes de adicionar a tarefa.", "Campos obrigat�rios", JOptionPane.WARNING_MESSAGE);
            } else {
                String data = dataDia + "/" + dataMes + "/" + dataAno;
                tarefaController.adicionarTarefa(new Tarefa(nome, descricao, categoria, data, 0));

                // Limpa os campos ap�s adicionar a tarefa
                nomeField.setText("");
                descricaoField.setText("");
                dataFieldDia.setText("");
                dataFieldMes.setText("");
                dataFieldAno.setText("");
            }
        });

        return panel;
    }


    private JPanel criarTelaListarTarefas() {
        JPanel panel = new JPanel(new BorderLayout());

        JTextArea areaTarefas = new JTextArea();
        areaTarefas.setEditable(false);
        areaTarefas.setFont(new Font("Arial", Font.PLAIN, 14));
        areaTarefas.setForeground(Color.DARK_GRAY);
        areaTarefas.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        areaTarefas.setBackground(new Color(240, 248, 255));

        panel.add(new JScrollPane(areaTarefas), BorderLayout.CENTER);

        JPanel optionsPanel = new JPanel(new FlowLayout());
        String[] opcoes = {"Listar Todas", "Listar Ordenadas"};
        JComboBox<String> comboBox = new JComboBox<>(opcoes);
        JLabel criterioLabel = new JLabel("Crit�rio:");
        criterioLabel.setVisible(false);
        JTextField criterioField = new JTextField(10);
        criterioField.setVisible(false);

        JButton listarButton = new JButton("Listar");
        estilizarBotao(listarButton);

        TarefaController tarefaController = new TarefaController();

        optionsPanel.add(comboBox);
        optionsPanel.add(criterioLabel);
        optionsPanel.add(criterioField);
        optionsPanel.add(listarButton);
        panel.add(optionsPanel, BorderLayout.NORTH);

        comboBox.addActionListener(e -> {
            String opcao = (String) comboBox.getSelectedItem();
            boolean isOrdenada = "Listar Ordenadas".equals(opcao);
            criterioLabel.setVisible(isOrdenada);
            criterioField.setVisible(isOrdenada);
            if (!isOrdenada) {
                criterioField.setText("");
            }
        });

        listarButton.addActionListener(e -> {
            areaTarefas.setText("");

            if ("Listar Todas".equals(comboBox.getSelectedItem())) {
                List<Tarefa> todasTarefas = tarefaController.listarTarefas();
                for (Tarefa tarefa : todasTarefas) {
                    areaTarefas.append(formatarTarefa(tarefa) + "\n---------------------------------\n");
                }
            } else if ("Listar Ordenadas".equals(comboBox.getSelectedItem())) {
                String criterio = criterioField.getText();
                if (criterio.isEmpty()) {
                    JOptionPane.showMessageDialog(panel, "Por favor, preencha o crit�rio para ordena��o.", 
                                                  "Erro", JOptionPane.WARNING_MESSAGE);
                } else {
                    List<Tarefa> tarefasOrdenadas = tarefaController.listarTarefasOrdenadas(criterio);
                    for (Tarefa tarefa : tarefasOrdenadas) {
                        areaTarefas.append(formatarTarefa(tarefa) + "\n---------------------------------\n");
                    }
                }
            }
        });

        return panel;
    }

    private JPanel criarTelaFiltrarTarefas() {
        JPanel panel = new JPanel(new BorderLayout());

        // �rea de filtro no topo da tela
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        filterPanel.setBackground(new Color(230, 240, 250));

        JLabel categoriaLabel = new JLabel("Categoria:");
        categoriaLabel.setFont(new Font("Arial", Font.BOLD, 14));
        categoriaLabel.setForeground(Color.DARK_GRAY);

        String[] categorias = {"Estudos", "Dom�stico", "Trabalho", "Variados"};
        JComboBox<String> categoriaComboBox = new JComboBox<>(categorias);
        categoriaComboBox.setFont(new Font("Arial", Font.PLAIN, 14));
        categoriaComboBox.setBackground(Color.WHITE);

        JButton filtrarButton = new JButton("Filtrar");
        estilizarBotao(filtrarButton);

        filterPanel.add(categoriaLabel);
        filterPanel.add(categoriaComboBox);
        filterPanel.add(filtrarButton);

        panel.add(filterPanel, BorderLayout.NORTH);

        // �rea de exibi��o das tarefas filtradas
        JTextArea areaFiltrada = new JTextArea();
        areaFiltrada.setEditable(false);
        areaFiltrada.setFont(new Font("Arial", Font.PLAIN, 14));
        areaFiltrada.setForeground(Color.DARK_GRAY);
        areaFiltrada.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        areaFiltrada.setBackground(new Color(240, 248, 255));

        panel.add(new JScrollPane(areaFiltrada), BorderLayout.CENTER);

        // A��o do bot�o Filtrar
        filtrarButton.addActionListener(e -> {
            String categoriaFiltro = (String) categoriaComboBox.getSelectedItem();
            TarefaController tarefaController = new TarefaController();
            List<Tarefa> tarefasFiltradas = tarefaController.buscarTarefasPorCategoria(categoriaFiltro);
            StringBuilder tarefasFiltradasTexto = new StringBuilder();

            for (Tarefa tarefa : tarefasFiltradas) {
                tarefasFiltradasTexto.append("Tarefa: ").append(tarefa.getNome()).append("\n")
                                     .append("Descri��o: ").append(tarefa.getDescricao()).append("\n")
                                     .append("Data: ").append(tarefa.getData()).append("\n\n");
            }

            areaFiltrada.setText(tarefasFiltradasTexto.toString());
        });

        return panel;
    }


    private void estilizarBotao(JButton botao) {
        botao.setBackground(new Color(70, 130, 180));
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("Arial", Font.BOLD, 12));
        botao.setFocusPainted(false);
        botao.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        botao.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        botao.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                botao.setBackground(new Color(100, 149, 237));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                botao.setBackground(new Color(70, 130, 180));
            }
        });
    }

    private String formatarTarefa(Tarefa tarefa) {
        return String.format(
            "Nome: %s\nDescri��o: %s\nData: %s\nCategoria: %s",
            tarefa.getNome(), tarefa.getDescricao(), tarefa.getData(), tarefa.getCategoria()
        );
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TelaMenu menu = new TelaMenu();
            menu.setVisible(true);
        });
    }
}
