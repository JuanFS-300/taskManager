package taskManager_2;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TarefaController implements TarefaDAO {

    @Override
    public void adicionarTarefa(Tarefa tarefa) {
        String checkDataSQL = "SELECT id FROM datas WHERE dia = ? AND mes = ? AND ano = ?";
        String dataSQL = "INSERT INTO datas (dia, mes, ano) VALUES (?, ?, ?)";
        String tarefaSQL = "INSERT INTO tarefas (nome_tarefa, descricao, categoria, data_id) VALUES (?, ?, ?, ?)";
        int dataId = -1;

        try (Connection connection = Dao.getConnection()) {
            connection.setAutoCommit(false);

            // Verificar se a data j� existe
            String[] dataParts = tarefa.getData().split("/");
            int dia = Integer.parseInt(dataParts[0]);
            int mes = Integer.parseInt(dataParts[1]);
            int ano = Integer.parseInt(dataParts[2]);

            try (PreparedStatement checkDataStmt = connection.prepareStatement(checkDataSQL)) {
                checkDataStmt.setInt(1, dia);
                checkDataStmt.setInt(2, mes);
                checkDataStmt.setInt(3, ano);
                try (ResultSet resultSet = checkDataStmt.executeQuery()) {
                    if (resultSet.next()) {
                        // Data j� existe, obtenha o id
                        dataId = resultSet.getInt("id");
                    } else {
                        // Data n�o existe, insira uma nova
                        try (PreparedStatement dataStmt = connection.prepareStatement(dataSQL, PreparedStatement.RETURN_GENERATED_KEYS)) {
                            dataStmt.setInt(1, dia);
                            dataStmt.setInt(2, mes);
                            dataStmt.setInt(3, ano);
                            dataStmt.executeUpdate();

                            try (ResultSet generatedKeys = dataStmt.getGeneratedKeys()) {
                                if (generatedKeys.next()) {
                                    dataId = generatedKeys.getInt(1);
                                } else {
                                    throw new SQLException("Falha ao obter o ID da data.");
                                }
                            }
                        }
                    }
                }

                // Inserir a tarefa
                try (PreparedStatement tarefaStmt = connection.prepareStatement(tarefaSQL)) {
                    tarefaStmt.setString(1, tarefa.getNome());
                    tarefaStmt.setString(2, tarefa.getDescricao());
                    tarefaStmt.setString(3, tarefa.getCategoria());
                    tarefaStmt.setInt(4, dataId);
                    tarefaStmt.executeUpdate();
                }

                connection.commit();
                JOptionPane.showMessageDialog(null, "Tarefa adicionada com sucesso ao banco de dados!");

            } catch (SQLException e) {
                connection.rollback();  // Reverte a transa��o em caso de erro
                e.printStackTrace();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    public List<Tarefa> listarTarefas() {
        List<Tarefa> tarefas = new ArrayList<>();
        String query = "SELECT t.*, d.dia, d.mes, d.ano FROM Tarefas t JOIN datas d ON t.data_id = d.id";

        try (Connection connection = Dao.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome_tarefa");
                String descricao = rs.getString("descricao");
                String categoria = rs.getString("categoria");
                String data = rs.getInt("dia") + "/" + rs.getInt("mes") + "/" + rs.getInt("ano");
                tarefas.add(new Tarefa(categoria, nome, descricao, data, id));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tarefas;
    }

    @Override
    public List<Tarefa> listarTarefasOrdenadas(String criterio) {
        List<Tarefa> tarefas = new ArrayList<>();
        String query = "SELECT t.*, d.dia, d.mes, d.ano FROM Tarefas t JOIN datas d ON t.data_id = d.id ORDER BY " + criterio;

        try (Connection connection = Dao.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome_tarefa");
                String descricao = rs.getString("descricao");
                String categoria = rs.getString("categoria");
                String data = rs.getInt("dia") + "/" + rs.getInt("mes") + "/" + rs.getInt("ano");

                tarefas.add(new Tarefa(categoria, nome, descricao, data, id));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Erro ao listar tarefas ordenadas: " + e.getMessage());
            e.printStackTrace();
        }

        return tarefas;
    }

    @Override
    public List<Tarefa> buscarTarefasPorCategoria(String categoria) {
        List<Tarefa> tarefas = new ArrayList<>();
        String query = "SELECT t.id, t.nome_tarefa, t.descricao, t.categoria, CONCAT(d.dia, '/', d.mes, '/', d.ano) AS data " +
                       "FROM tarefas t " +
                       "JOIN datas d ON t.data_id = d.id " +
                       "WHERE t.categoria = ?";

        try (Connection connection = Dao.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {

            stmt.setString(1, categoria);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome_tarefa");
                String descricao = rs.getString("descricao");
                String data = rs.getString("data");

                Tarefa tarefa = new Tarefa(categoria, nome, descricao, data, id);
                tarefas.add(tarefa);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tarefas;
    }
}
