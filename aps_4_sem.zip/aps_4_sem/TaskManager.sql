-- Criando o banco de dados
CREATE DATABASE TaskManager;

-- Usando o banco de dados
USE TaskManager;

-- Criando a tabela de Tarefas
CREATE TABLE Tarefas (
    id INT PRIMARY KEY,
    nome_tarefa VARCHAR(255),
    categoria VARCHAR(100),
    descricao VARCHAR(255),
    data_id INT,
    FOREIGN KEY (data_id) REFERENCES Datas(id)
);

-- Criando a tabela de Datas
CREATE TABLE Datas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    dia INT,
    mes INT,
    ano INT
);
