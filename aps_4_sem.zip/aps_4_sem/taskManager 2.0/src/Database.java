import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Database {
	private final static String USER = "root";
	private final static String PASS = "Jfsc2003_";
	private final static String DATABASE = "TaskManager";
	private final static String URL = "jdbc:mysql://localhost:3306/" + DATABASE;
	
	
    public static Connection getConnection() {
    	try(Connection c = DriverManager.getConnection(URL, USER, PASS)){
			System.out.println("conexao feita");
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		return null;}
    
}
