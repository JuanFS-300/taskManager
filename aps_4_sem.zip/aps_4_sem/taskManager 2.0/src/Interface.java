import java.awt.*;

import javax.swing.*;



public class Interface extends JFrame {

    private DefaultListModel<String> taskListModel;  // Modelo da lista de tarefas

    private JList<String> taskList;  // Lista de tarefas exibida na interface



    public Interface() {

        // Configura��o da janela principal

        setTitle("Gerenciador de Tarefas");

        setSize(400, 300);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setLocationRelativeTo(null);



        // Inicializando o modelo e a lista de tarefas

        taskListModel = new DefaultListModel<>();

        taskList = new JList<>(taskListModel);

        JScrollPane scrollPane = new JScrollPane(taskList);



        // Criando o menu

        JMenuBar menuBar = new JMenuBar();

        JMenu menu = new JMenu("Op��es");

        JMenuItem addTaskItem = new JMenuItem("Adicionar Tarefa");

        JMenuItem removeTaskItem = new JMenuItem("Remover Tarefa");



        // Adicionando itens ao menu

        menu.add(addTaskItem);

        menu.add(removeTaskItem);

        menuBar.add(menu);

        setJMenuBar(menuBar);



        // Adicionando a��es aos itens do menu

        addTaskItem.addActionListener(e -> {

            String task = JOptionPane.showInputDialog("Digite a tarefa:");

            if (task != null && !task.trim().isEmpty()) {

                taskListModel.addElement(task);

            }

        });



        removeTaskItem.addActionListener(e -> {

            int selectedIndex = taskList.getSelectedIndex();

            if (selectedIndex != -1) {

                taskListModel.remove(selectedIndex);

            } else {

                JOptionPane.showMessageDialog(this, "Selecione uma tarefa para remover.");

            }

        });



        // Criando painel de bot�es e definindo a��es para os bot�es

        Botoes botoes = new Botoes(

            e -> JOptionPane.showMessageDialog(this, "Menu aberto."),

            e -> {

                String task = JOptionPane.showInputDialog("Digite a tarefa:");

                if (task != null && !task.trim().isEmpty()) {

                    taskListModel.addElement(task);

                }

            },

            e -> {

                if (taskListModel.isEmpty()) {

                    JOptionPane.showMessageDialog(this, "N�o h� tarefas para exibir.");

                } else {

                    JOptionPane.showMessageDialog(this, "Exibindo todas as tarefas.");

                }

            },

            e -> JOptionPane.showMessageDialog(this, "Perfil aberto.")

        );



        // Adicionando os pain�is � janela principal

        add(botoes, BorderLayout.NORTH);

        add(scrollPane, BorderLayout.CENTER);

    }



    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> new Interface().setVisible(true));

    }

}
