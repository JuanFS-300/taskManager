

import java.awt.*;

import java.awt.event.ActionListener;

import javax.swing.*;



public class Botoes extends JPanel {

    private JButton menuButton;

    private JButton newTaskButton;

    private JButton viewTasksButton;

    private JButton profileButton;



    public Botoes(ActionListener menuAction, ActionListener newTaskAction, ActionListener viewTasksAction, ActionListener profileAction) {

        setLayout(new FlowLayout(FlowLayout.LEFT));



        // Inicializando bot�es

        menuButton = new JButton("Menu");

        newTaskButton = new JButton("Nova Tarefa");

        viewTasksButton = new JButton("Visualizar Tarefas");

        profileButton = new JButton("Perfil");



        // Adicionando os bot�es ao painel

        add(menuButton);

        add(newTaskButton);

        add(viewTasksButton);

        add(profileButton);



        // Configurando as a��es dos bot�es

        menuButton.addActionListener(menuAction);

        newTaskButton.addActionListener(newTaskAction);

        viewTasksButton.addActionListener(viewTasksAction);

        profileButton.addActionListener(profileAction);

    }

}

